package com.vidvaan.corejava.demo;

import java.util.Scanner;

public class NumberSeries {
	public static void main(String[] args) {
		@SuppressWarnings("resource")
		Scanner scanner=new Scanner(System.in);
		System.out.println("enter the no of series required :");
		int n=scanner.nextInt();
		System.out.println("The no series is:");
	for (int i = 0; i <=n; i++) {
		System.out.println(i);
		}	
		}}
