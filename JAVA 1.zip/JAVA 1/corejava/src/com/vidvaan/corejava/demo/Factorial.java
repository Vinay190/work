package com.vidvaan.corejava.demo;

import java.util.Scanner;

public class Factorial {
	public static void main(String[] args) {
		@SuppressWarnings("resource")
		Scanner scanner=new Scanner(System.in);
		System.out.println("enter a number you need factorial: ");
		int n=scanner.nextInt();
		long p=n;long f,s;
		for(int i=1; i<n ;i++)
		{
			f=p;s=n-i;
		p=f*s;
		}
		System.out.println("The factorial of the number you entered is:"+p);
		
	}

}
