package com.vidvaan.corejava.demo;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class AcceptInteger {
	public static void main(String[] args) throws NumberFormatException, IOException {
		
		BufferedReader obj=new BufferedReader(new InputStreamReader(System.in));
		System.out.println("enter a int value:");
		int num=Integer.parseInt(obj.readLine());
		System.out.println("you entered:"+num);
	}

}
