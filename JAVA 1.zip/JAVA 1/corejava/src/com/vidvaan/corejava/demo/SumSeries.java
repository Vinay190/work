package com.vidvaan.corejava.demo;

import java.util.Scanner;

public class SumSeries {
	public static void main(String[] args) {
		@SuppressWarnings("resource")
		Scanner scanner = new Scanner (System.in);
		System.out.println("enter the num of sequences required: ");
		int n=scanner.nextInt();
		int sum=0;
		for (int i = 1; i <= n; i++) {
			sum=sum+i;
			}
		System.out.println("the sum of the series is:" +sum);
	}
}
