package com.vidvaan.corejava.demo;

import java.util.Scanner;

public class LeapYear {
	public static void main(String[] args) {
		@SuppressWarnings("resource")
		Scanner scanner=new Scanner(System.in);
		System.out.printf("enter the year:");
		int y =scanner.nextInt();
		if (y%100==0&&y%400==0) {
			System.out.println("entered year in centurires is a leap year");
		}
		else if (y%100!=0&&y%4==0) {
			System.out.println("entered year is a leap year ");
			}
		else {
			System.out.println("entered year is not a leap year");
		}
	}

}
