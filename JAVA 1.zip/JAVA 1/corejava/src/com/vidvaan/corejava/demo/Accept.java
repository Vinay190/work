package com.vidvaan.corejava.demo;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class Accept {
	public static void main(String[] args) throws IOException {

		BufferedReader obj = new BufferedReader(
				new InputStreamReader(System.in));
		System.out.println("enter a name:");
		String name = obj.readLine();
		System.out.println("welcome:" + name);

	}
}
