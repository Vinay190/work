package com.vidvaan.corejava.demo;

import java.util.Scanner;

public class ReverseNumber {
	public static void  main(String[] args) {
		@SuppressWarnings("resource")
		Scanner scanner=new Scanner(System.in);
		System.out.println("enter the number to be reversed: ");
		int num=scanner.nextInt();
		int num1=0;
		while (num>0) {
			int rev = num%10;
			num=num/10;
			num1=num1*10+rev;
			}
System.out.println("The reverse of the num you entered is:" +num1);
	}
}

