package com.vidvaan.corejava.demo;

import java.util.Scanner;

public class PrimeNumber {
	public static void main(String[] args) {
		@SuppressWarnings("resource")
		Scanner scanner = new Scanner(System.in);
		System.out.println("enter the num to check a prime number:");
		int n = scanner.nextInt();
		Boolean flag = true;
		for (int i = 2; i <= n / 2; i++) {
			if (n % i == 0) {
				flag = false;
				break;
			}
		}
		if (flag == true) {
			System.out.println("it is a prime");
		} else {
			System.out.println("it is not a prime");
		}
	}
}