package com.vidvaan.corejava.demo;

import java.util.Scanner;

public class FabonaciSeries {
public static void main(String[] args) {
	@SuppressWarnings("resource")
	Scanner scanner=new Scanner(System.in);
	System.out.println("enter the number of sequences needed: ");
	int n=scanner.nextInt();
	System.out.println("The required fabinoci series is: ");
	int f=0,s=1;
	System.out.println(f);
	System.out.println(s);
	int i=0;
	while (i<=n-3) {
		int t=f+s;
		System.out.println(t);
		f=s;s=t;
		i++;
		}
}
}
