package com.vidvaan.corejava.inheritance;

public class TestClass extends CropLoan {
	
	 void personDetails() {
		System.out.println("person details of Test class");
	}
	public static void main(String[] args) {

		TestClass testclass = new TestClass();
		testclass.personDetails();
		
	}

}
