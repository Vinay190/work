package com.vidvaan.corejava.inheritance;

public class CropLoan extends PersonLoan {
	

	void personDetails() {
		System.out.println("person details of crop loan");
	}

	public void landDetails() {
		System.out.println("land details of crop loan");
	}
	public void healthDetails()
	{
		System.out.println("Health details of croploan");
	}

}
