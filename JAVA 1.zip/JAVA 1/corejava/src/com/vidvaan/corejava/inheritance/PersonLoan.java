package com.vidvaan.corejava.inheritance;

public class PersonLoan {
	 void personDetails()
	{
		System.out.println("person details of personal loan");
	}
	public void workDetails()
	{
		System.out.println("work details of personal details");
	}
public void healthDetails()
{
	System.out.println("Health details of personal loan");
}

}
