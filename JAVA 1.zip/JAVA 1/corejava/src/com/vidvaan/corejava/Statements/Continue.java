package com.vidvaan.corejava.Statements;

import java.util.Scanner;

public class Continue {
	public static void main(String[] args) {
		@SuppressWarnings("resource")
		Scanner scanner = new Scanner(System.in);
		System.out.println("enter the no of series required :");
		int n = scanner.nextInt();
		System.out.println("The no series is:");
		for (int i = 0; i <= n; i++) {
			if (i == 4 ) {
				continue;
			}
			System.out.println(i);
		}
	}
}
