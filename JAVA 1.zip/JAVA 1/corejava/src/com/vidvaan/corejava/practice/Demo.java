package com.vidvaan.corejava.practice;

import java.util.Scanner;

class Person {
	int age;
	String name;

	Person() {
		age = 24;
		name = "manoj";
	}

	Person(int i, String s) {
		name = s;
		age = i;
	}

	void talk() {
		System.out.println("hello i am " + name);
		System.out.println("hello i am " + age);
	}
}

class Demo {

	public static void main(String[] args) {
		Person nam = new Person();
		nam.talk();
		@SuppressWarnings("resource")
		Scanner sca = new Scanner(System.in);
		System.out.println("enter age and name");
		int x = sca.nextInt();
		String name = sca.next();
		Person sita = new Person(x, name);
		sita.talk();
	}
}
