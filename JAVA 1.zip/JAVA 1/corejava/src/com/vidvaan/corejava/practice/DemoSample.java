package com.vidvaan.corejava.practice;

import java.util.Scanner;

class Student {
	private int age;
	private String name;

	void accept() {
		@SuppressWarnings("resource")
		Scanner sca = new Scanner(System.in);
		System.out.println("enter the name ");
		name = sca.next();
		System.out.println("enter age");
		age = sca.nextInt();
	}

	void check() {
		if (age <= 20) {
			System.out.println("the person is young");
			System.out.println("name:" + name);
			System.out.println("age:" + age);
		} else if (age > 20 && age <= 30) {
			System.out.println("person is middle age" + name + age);

		} else if (age > 30 && age <= 100) {
			System.out.println("person is old" + name + age);
		}
	}
}

class DemoSample {
	public static void main(String[] args) {
		Student stu = new Student();
		stu.accept();
		stu.check();
	}
}