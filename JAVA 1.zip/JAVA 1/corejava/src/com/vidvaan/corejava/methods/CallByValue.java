package com.vidvaan.corejava.methods;

import java.util.Scanner;

public class CallByValue {
	void sum(int a,int b){
	System.out.println("The sum of two numbers is:");	
		System.out.println(a+b);
	}
void sub(int a,int b){
	System.out.println("The substraction of two numbers is:");
	System.out.println(a-b);
}
public static void main(String[] args) {
	CallByValue calculations=new CallByValue();
	@SuppressWarnings("resource")
	Scanner scanner=new Scanner(System.in);
	System.out.println("enter the two values");
	int a=scanner.nextInt();
	int b=scanner.nextInt();
	calculations.sum(a,b);
	calculations.sub(a,b);
	
	}
}
