package com.vidvaan.corejava.methods;

import java.util.Scanner;

class StringSwitchCase {
	@SuppressWarnings("resource")
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		System.out.println("enter the string name");
		System.out.println("1.aruna 2.manoj 3.sanju");
		String name = scanner.next();
		switch (name) {
		case "manoj":
			System.out.println("manoj son of aruna");
			break;
		case "aruna":
			System.out.println("aruna mother of manoj");
			break;
		case "sanju":
			System.out.println("sanju is sweet baby");
			break;
		default:
			System.out.println("entered name is not valid");
			break;
		}
	}
}
