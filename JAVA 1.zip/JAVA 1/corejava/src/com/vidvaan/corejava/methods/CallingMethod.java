package com.vidvaan.corejava.methods;

import java.util.Scanner;

public class CallingMethod {
	int cube(int a) {
		int b = squre(a);
		return b * a;
	}

	int squre(int a) {
		return a * a;
	}

	public static void main(String[] args) {
		CallingMethod calculations = new CallingMethod();
		@SuppressWarnings("resource")
		Scanner scanner = new Scanner(System.in);
		System.out.println("enter square number");
		int n = scanner.nextInt();
		System.out.println("enter the cube number");
		int m = scanner.nextInt();
		int a = calculations.squre(n);
		int na = calculations.cube(m);
		System.out.println("The product of the number you entered is:");
		System.out.println(a);
		System.out.println("The cube of the number you entered is:");
		System.out.println(na);
	}
}
