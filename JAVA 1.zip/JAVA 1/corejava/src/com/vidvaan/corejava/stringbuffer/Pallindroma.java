package com.vidvaan.corejava.stringbuffer;

import java.util.Scanner;

public class Pallindroma {
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		System.out.println("enter the string ");
		String st = scanner.next();
		StringBuffer sb = new StringBuffer(st);
		sb.reverse();
		System.out.println(sb);
		scanner.close();
	}

}
