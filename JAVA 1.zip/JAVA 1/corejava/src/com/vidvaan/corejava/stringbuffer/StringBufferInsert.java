package com.vidvaan.corejava.stringbuffer;

import java.util.Scanner;

public class StringBufferInsert {
	public static void main(String[] args) {
		@SuppressWarnings("resource")
		Scanner scanner = new Scanner(System.in);
		String name=scanner.next();
		StringBuffer st=new StringBuffer("chennai city");
		st.insert(7, name);
		System.out.println(st);
		
		
		
	}

}
