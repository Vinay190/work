package com.vidvaan.corejava.stringbuffer;

import java.util.Scanner;

public class StringBufferApend {
	public static void main(String[] args) {
		Scanner sca = new Scanner(System.in);
		System.out.println("enter the first name");
		String name = sca.next();
		System.out.println("enter the middle name");
		String nam = sca.next();
		StringBuffer str = new StringBuffer(name);
		str.append(nam);
		System.out.println("enter the last name");
		String na = sca.next();
		str.append(na);
		System.out.println("The full name you entered is " + str);
		sca.close();
	}

}
