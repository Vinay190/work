package com.vidvaan.corejava.stringbuffer;

import java.util.Scanner;

public class StringBufferAppend {

	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		System.out.println("enter the string name");
		String name = scanner.next();
		StringBuffer st = new StringBuffer(name);
		st.append("kumar");
		System.out.println(st);
		scanner.close();
	}

}
