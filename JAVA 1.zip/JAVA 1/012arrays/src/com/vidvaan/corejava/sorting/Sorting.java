package com.vidvaan.corejava.sorting;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class Sorting {
	
	public static void main(String[] args) throws IOException {
InputStreamReader reader=new InputStreamReader(System.in);
BufferedReader reader2=new BufferedReader(reader);
System.out.println("enter the size of the array");
int n=Integer.parseInt(reader2.readLine());
int[] a=new int[n];
for (int i = 0; i < a.length; i++) {
	int t=1;
	System.out.println("enter the element"+t);
	a[i]=Integer.parseInt(reader2.readLine());
	t++;
}
System.out.println("The elements you entered is::");
for (int i = 0; i < a.length; i++) {
	System.out.println(a[i]);
}
int t;
for (int i = 0; i < a.length; i++) {
	if(a[i]>a[i+1]){
		t=a[i];
		a[i]=a[i+1];
		a[i+1]=t;
	}
	else
		continue;
}
for (int i = 0; i < a.length; i++) {
	System.out.println("sorted elements are");
	System.out.println(a[i]);
}
	}

}
