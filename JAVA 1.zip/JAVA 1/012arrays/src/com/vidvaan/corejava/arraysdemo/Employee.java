package com.vidvaan.corejava.arraysdemo;

class Employee {
	int id;
	String name;

	Employee(int i, String n) {
		id = i;
		name = n;
	}

	void display() {
		System.out.println(id + "/t" + name);
	}

}
