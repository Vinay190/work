package com.vidvaan.corejava.arraysdemo;

import java.util.Scanner;

class Group {
	public static void main(String[] args) {
		Scanner sca=new Scanner(System.in);
		Employee arr[]=new Employee[5];
		for(int i=0;i<5;i++){
			System.out.println("enter id");
			int id=sca.nextInt();
			System.out.println("enter name");
			String name=sca.next();
			arr[i]=new Employee(id,name);
		}
		System.out.println("The employee data is:");
		for(int i=0;i<arr.length;i++){
			arr[i].display();
		}
	}

}
