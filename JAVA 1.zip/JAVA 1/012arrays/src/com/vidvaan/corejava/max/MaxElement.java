package com.vidvaan.corejava.max;

import java.util.Scanner;

public class MaxElement {
	int max;
public void maxelement(int[] a){
	for (int i = 0; i < a.length; i++) {
		if(max<a[i]){
			max=a[i];
		}
	}
	System.out.println("max element is:"+max);
}
	
	public static void main(String[] args) {
int max;
Scanner scanner=new Scanner(System.in);
int n=scanner.nextInt();
int[] a=new int[n];
for (int i = 0; i < a.length; i++) {
	System.out.println("enter chei ra erripuka:");
	a[i]=scanner.nextInt();
}
for (int i = 0; i < a.length; i++) {
	System.out.println(a[i]);
}

MaxElement element=new MaxElement();
element.maxelement(a);
}

}
