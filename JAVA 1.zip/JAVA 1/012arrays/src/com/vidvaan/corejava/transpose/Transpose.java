package com.vidvaan.corejava.transpose;

import java.util.Scanner;

public class Transpose {
	public void transpose(int[][] a,int r,int c){
		System.out.println("The transpose elements are ::");
		for (int i = 0; i < c; i++) {
			for (int j = 0; j < r; j++) {
				System.out.println(a[i][j]);
			}
			System.out.println(" ");
		}
	}
	public static void main(String[] args) {

		Scanner scanner=new Scanner(System.in);
		System.out.println("enter the row size");
		int r=scanner.nextInt();
		System.out.println("enter the column size");
	    int c=scanner.nextInt();
	    int[][] a=new int[r][c];
	    for (int i = 0; i <r; i++) {
			for (int j = 0; j < c; j++) {
				System.out.println("enter the element");
				a[i][j]=scanner.nextInt();
			}
		}
	    System.out.println("the entered elements are:");
	    for (int i = 0; i <r; i++) {
			for (int j = 0; j < c; j++) {
				System.out.print( a[i][j]+"  " );
			}
			System.out.println(" ");
	}
Transpose transpose=new Transpose();
transpose.transpose(a, r, c);
	}}
