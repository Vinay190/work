package com.lvyshultd.corejava.hellovyshu;

 class HelloVyshu {

	 public static void main(String[] args){
		 System.out.println("Hello vyshu.....");
		 System.out.println("how do you do?");
	 }
	 
}