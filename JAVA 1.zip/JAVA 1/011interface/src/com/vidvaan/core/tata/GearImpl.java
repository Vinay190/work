package com.vidvaan.core.tata;

public  interface GearImpl extends Tata,Suziki {


}
