package com.vidvaan.core.tata;

public class Test implements Suziki,Tata{

	public void gear() {
     		
	}

	public void steer() {
		
	}

}
