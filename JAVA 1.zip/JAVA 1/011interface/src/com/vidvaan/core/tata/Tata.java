package com.vidvaan.core.tata;

public interface Tata {
public void gear();
	public void steer();

	}
