package com.vidvaan.core.tata;

public interface Suziki {
  void gear();
public void steer();
	}

