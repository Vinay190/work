package com.vidvaan.corejava.listiterator;

import java.util.ArrayList;
import java.util.ListIterator;

 class ArrayListDemo {
	 public static void main(String[] args) {
		ArrayList arraylist=new ArrayList<>();
		arraylist.add(007);
		arraylist.add(007);
		arraylist.add(null);
		arraylist.add("manoj");
		ListIterator iterator=arraylist.listIterator();
		while(iterator.hasNext()){
			Object object=iterator.next();
			if(object==null){
				iterator.remove();
			}
		}
		System.out.println(arraylist);
	}

}
