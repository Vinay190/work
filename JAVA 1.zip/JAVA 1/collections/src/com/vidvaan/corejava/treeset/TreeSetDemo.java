package com.vidvaan.corejava.treeset;

import java.util.Iterator;
import java.util.TreeSet;

class TreeSetDemo {
	public static void main(String[] args) {
		TreeSet treeset=new TreeSet<>();
		treeset.add(1);
		treeset.add(1);
		treeset.add(2);
		try{
			treeset.add("manoj");
		}
		catch(Exception e){
			System.out.println("heterogenous elemnts not allowed");
		}
		try{
			treeset.add(null);
		}
		catch(Exception e){
           System.out.println("nulls not allowed");	
		}
		System.out.println(treeset);
		Iterator iterator=treeset.iterator();
		while(iterator.hasNext()){
			System.out.println(iterator.next());
		}
	}

}
