package com.vidvaan.corejava.linkedlistdemo;

import java.util.ArrayList;
import java.util.LinkedList;

public class Test {
	public static void main(String[] args) {
		ArrayList arraylist=new ArrayList<>();
		arraylist.add("manoj");
		arraylist.add(1041020042);
		arraylist.add("srm");
		LinkedList linkedlist=new LinkedList<>();
		linkedlist.add("manoj");
		linkedlist.add(888385513);
		linkedlist.add("indian bank");
		linkedlist.add(arraylist);
		System.out.println(linkedlist.removeFirst());
		System.out.println(linkedlist);
		System.out.println(linkedlist.contains(arraylist));
}
}