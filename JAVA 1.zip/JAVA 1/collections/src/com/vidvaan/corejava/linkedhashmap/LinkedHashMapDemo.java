package com.vidvaan.corejava.linkedhashmap;

import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Set;

 class LinkedHashMapDemo {
public static void main(String[] args) {
	LinkedHashMap lm=new LinkedHashMap();
	lm.put(2, 32);
	lm.put("a", 1);
	lm.put(3, "b");
	System.out.println(lm);
	Set s=lm.keySet();
	Iterator itr=s.iterator();
	while(itr.hasNext()){
		Object object=itr.next();
		lm.get(object);
	}
	System.out.println(lm);
}
}
