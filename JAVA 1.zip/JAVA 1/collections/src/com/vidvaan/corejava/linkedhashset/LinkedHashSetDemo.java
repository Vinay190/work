package com.vidvaan.corejava.linkedhashset;

import java.util.Iterator;
import java.util.LinkedHashSet;

class LinkedHashSetDemo {
	public static void main(String[] args) {
		LinkedHashSet linkedset=new LinkedHashSet<>();
		linkedset.add(1);
		linkedset.add(1);
		linkedset.add(2);
		linkedset.add("manoj");
		linkedset.add(null);
		System.out.println(linkedset);
		Iterator iterator=linkedset.iterator();
		while(iterator.hasNext()){
			System.out.println(iterator.next());
		}
	}

}
