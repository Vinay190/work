package com.vidvaan.corejava.linkedlist;

import java.util.LinkedList;
import java.util.ListIterator;
 class LinkedListDemo {
	 public static void main(String[] args) {
	LinkedList linkedlist =new LinkedList<>();
	linkedlist.add("manoj");
	linkedlist.add(101);
	linkedlist.add(101);
	linkedlist.add(707);
	linkedlist.add(10f);
	System.out.println(linkedlist);
	System.out.println(linkedlist.getFirst());
	System.out.println(linkedlist);
	System.out.println(linkedlist.getLast());
	System.out.println(linkedlist.indexOf(linkedlist));
	Object object=linkedlist.clone();
	System.out.println(linkedlist.element());
	ListIterator iterator=linkedlist.listIterator();
	while(iterator.hasNext()){
		System.out.println(iterator.next());
	}
	System.out.println(linkedlist.poll());
	System.out.println(linkedlist);
	System.out.println(object);
}      
}
