package com.vidvaan.corejava.hashset;

import java.util.HashSet;
import java.util.Iterator;

class HashSetDemo {
	public static void main(String[] args) {
		HashSet hashset=new HashSet<>();
		hashset.add("manoj");
		hashset.add(101);
		hashset.add(101);
		hashset.add(273711);
		hashset.add(new Employee(1041020042,"manoj",15000));
		System.out.println(hashset);
		Iterator iterator=hashset.iterator();
		while(iterator.hasNext()){
			System.out.println(iterator.next());
		}
		
	}

}
