package com.vidvaan.corejava.hashset;

class Employee {
	private int id;
	private String name;
	private double sal;
	Employee(int id,String name,double sal){
		this.id=id;
		this.name=name;
		this.sal=sal;
	}
void get(){
	System.out.println(id);
	System.out.println(name);
	System.out.println(sal);
}
}
