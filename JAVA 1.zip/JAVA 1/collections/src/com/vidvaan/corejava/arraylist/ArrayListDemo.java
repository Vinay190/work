package com.vidvaan.corejava.arraylist;
import java.util.ArrayList;
import java.util.Iterator;
public class ArrayListDemo {
	public static void main(String[] args) {
		ArrayList arraylist = new ArrayList<>();
		arraylist.add(9);
		arraylist.add("noj");
		arraylist.add(1, "ma");
		arraylist.add(null);
		System.out.println(arraylist);
		Iterator iterator = arraylist.iterator();
		while (iterator.hasNext()) {
			System.out.println(iterator.next());

		}
	}
}
