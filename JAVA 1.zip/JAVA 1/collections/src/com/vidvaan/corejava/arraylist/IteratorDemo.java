package com.vidvaan.corejava.arraylist;

import java.util.ArrayList;
import java.util.Iterator;

public class IteratorDemo {
	public static void main(String[] args) {
		ArrayList arraylist=new ArrayList<>();
		arraylist.add("hai");
		arraylist.add(917731138);
		arraylist.add(898);
		arraylist.add(null);
		Iterator iterator=arraylist.iterator();
		while(iterator.hasNext()){
			Object object =iterator.next();
			if(object==null){
				iterator.remove();
			}
		}
		System.out.println(arraylist);
	}
}
