package com.vidvaan.corejava.arraylist;

import java.util.ArrayList;
import java.util.HashSet;

class ArrayListVsHashSet {
	public static void main(String[] args) {
		ArrayList arraylist = new ArrayList<>();
		arraylist.add(1);
		arraylist.add(1);
		arraylist.add(2);
		arraylist.add("hello");
		arraylist.add(null);
		System.out.println("elemnts contained in array list are:" + arraylist);
		HashSet hashset = new HashSet<>();
		hashset.add(arraylist);
		System.out.println(hashset);	

	}

}
