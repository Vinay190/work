package com.vidvann.corejava.map;

import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

class MapDemo {
	public static void main(String[] args)  {
		HashMap h = new HashMap();
		h.put(1, "aruna");
		h.put(2, "manoj");
		h.put(3, "sanjai");
		h.put(4, 1041020042);
		h.put("laruna", 273711);
		h.put(null, null);
		h.put("praveen", "supriya");
		h.remove("laruna");
		System.out.println(h);
		System.out.println(h.isEmpty());
	//	Set s = h.entrySet();
		Set s=h.keySet();
	//	Iterator ite = s.iterator();
		Collection c=h.values();
		System.out.println(c);
		for (Object object : s) {
			System.out.println(object);

		}
	}

}
