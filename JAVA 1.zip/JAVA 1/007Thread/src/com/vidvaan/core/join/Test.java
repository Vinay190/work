package com.vidvaan.core.join;

public class Test {
public static void main(String[] args) {
	ThreadMy my=new ThreadMy();
	my.start();
	try {
		my.join();
	} catch (InterruptedException e) {
		e.printStackTrace();
	}
	for (int i = 0; i < 10; i++) {
		System.out.println("this is main thread");
	}
}
}
