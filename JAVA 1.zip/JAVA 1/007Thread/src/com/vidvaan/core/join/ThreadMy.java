package com.vidvaan.core.join;

public class ThreadMy extends Thread{
	public void run(){
		for (int i = 0; i <10; i++) {			
			System.out.println("this is child thread");
		}
	}

}
