package com.vidvaan.core.interrupt;

public class Ramesh extends Thread {
public void run(){
	try{
		for (int i = 0; i < 10; i++) {
			Thread.sleep(2000);
			System.out.println("This is child Thread");
		}
	}
	catch(InterruptedException e){
		System.out.println("interrupted");
	}
	
	
}
}
