package com.vidvaan.core.interrupt;

public class Testing {
public static void main(String[] args) {
	Ramesh r=new Ramesh();
	r.start();
	r.interrupt();
	for (int i = 0; i < 10; i++) {
		System.out.println("main thread");
	}
}
}
