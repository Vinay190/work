package com.vidvaan.corejava.threadsdemo;

public class Test {
	public static void main(String[] args) {
	Sample sam=new Sample();
     sam.setDaemon(true);
     System.out.println(sam.isDaemon());
     sam.start();
     try {
		Thread.sleep(30000);
	} catch (InterruptedException e) {
		
		e.printStackTrace();
	}
     System.out.println("main thread finished");
}
}