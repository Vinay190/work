package com.vidvaan.corejava.threadsdemo;

public class Sample extends Thread {
	int count=0;
	public void run() {
		while(true){
		method2();
		count++;
		try {
			sleep(2000);
		} catch (InterruptedException e) {
			
			e.printStackTrace();
		}
System.out.println("run method called");
	}}
 void method2(){
	System.out.println("inner method"+count);
}
}