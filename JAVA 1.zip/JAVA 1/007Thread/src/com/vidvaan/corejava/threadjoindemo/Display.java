package com.vidvaan.corejava.threadjoindemo;

public class Display {
	public synchronized void wish(String string){
		for (int i = 0; i < 10; i++) {
			System.out.println("good morning :"+string);
		try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		}
	}

}
