
package com.vidvaan.corejava.threadjoindemo;

public class ThreadJoinDemo  {
	public static void main(String[] args) {
		Display d1=new Display();
		Display d2=new Display();
		MyThread t1=new MyThread(d1, "raghu");
		MyThread t2=new MyThread(d2, "padhu");
		t1.start();
		t2.start();
		for (int i = 0; i < 10; i++) {
			System.out.println("This is main thread");
		}
	}
}
