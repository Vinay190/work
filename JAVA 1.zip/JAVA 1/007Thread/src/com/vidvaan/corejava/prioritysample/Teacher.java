package com.vidvaan.corejava.prioritysample;

public class Teacher extends Thread {

	public void run(){
		for (int i = 0; i < 10; i++) {
			System.out.println("run method: "+Thread.currentThread().getName());
		}
	}
	
}
