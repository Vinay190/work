package com.vidvaan.corejava.prioritysample;

public class Test {
public static void main(String[] args) {
	Teacher t=new Teacher();
	Teacher t2=new Teacher();
	t.setName("ramesh");
	t2.setName("manoj");
	t.setPriority(Thread.MAX_PRIORITY);
	t.setPriority(Thread.MIN_PRIORITY);
	t.start();
	t2.start();
	System.out.println("main thread priority"+Thread.currentThread().getPriority());
	System.out.println("ramesh thread priority"+t.getPriority());
	for(int i=0;i<10;i++){
		System.out.println("manoj thread"+t2.getPriority());
	}
	
}
}
