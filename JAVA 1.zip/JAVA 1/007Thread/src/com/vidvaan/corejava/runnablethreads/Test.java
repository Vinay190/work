package com.vidvaan.corejava.runnablethreads;

public class Test {
	public static void main(String[] args) {
		Thread thread = Thread.currentThread();
		System.out.println(thread.getName());
		System.out.println(thread.getPriority());
		thread.setPriority(10);
		System.out.println(thread.getPriority());

	}

}
