package com.vidvaan.corejava.runnablethreads;

public class ThreadDemo extends Thread  {

	@Override
	public void run() {
		for (int i = 0; i < 10; i++) {
		System.out.println("run method called-runnable");
		}
	}
	

}
