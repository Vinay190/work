package com.vidvaan.corejava.threads2;
public class Test  {
	public static void main(String[] args) {
		MyThread2 thread=new MyThread2();
		thread.start();
		System.out.println("main");
	}

	
	}


