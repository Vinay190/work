package com.vidvaan.corejava.threads2;

class MyThread2 extends Thread {
	public void run(int i) {
		System.out.println("arg method");
	}
public void start(){
	System.out.println("start method-our own");
	super.start();
}
	public void run() {
		System.out.println("run method");
	}
}
