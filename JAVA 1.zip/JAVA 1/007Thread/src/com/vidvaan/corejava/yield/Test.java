package com.vidvaan.corejava.yield;

public class Test {
	public static void main(String[] args) {
		MyThread thread = new MyThread();
		thread.start();
		thread.setPriority(5);
		for (int i = 0; i < 10; i++) {
//			try {
//				Thread.sleep(2000);
//			} catch (InterruptedException e) {
//				// TODO Auto-generated catch block
//				e.printStackTrace();
//			}
			System.out.println("this is main thread");
		}
	}

}
