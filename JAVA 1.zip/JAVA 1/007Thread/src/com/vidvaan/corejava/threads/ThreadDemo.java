package com.vidvaan.corejava.threads;

public class ThreadDemo {
	public static void main(String[] args) {
		MyThread mythread=new MyThread();
		mythread.start();
		MyThread2 mythread2=new MyThread2();
		Thread thread=new Thread(mythread2);
		thread.start();
		MyThread3 myThread3=new MyThread3();
		myThread3.start();
		for (int i = 0; i < 10; i++) {
			System.out.println("main thread");
		}
	}

}
