package com.vidvaan.corejava.threads;

public class MyThread3 extends Thread {
public void run(){
	System.out.println("MyThread3 thread");
}
}
