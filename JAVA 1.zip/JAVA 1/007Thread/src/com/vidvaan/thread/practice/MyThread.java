package com.vidvaan.thread.practice;

public class MyThread  extends Thread{
@Override
public void run() {
//System.out.println("this is run method"+Thread.currentThread().getName());
for (int i = 0; i < 100; i++) {
	System.out.println("my thread");
}
}
}

