package com.vidvaan.thread.practice;

public class Test {
public static void main(String[] args) {
//	System.out.println("main method started executing");
//	System.out.println(Thread.currentThread().getPriority());
	MyThread t=new MyThread();
	t.start();
//	t.setName("our thread");
	t.setPriority(1);
//	System.out.println(t.getName());
//	System.out.println(Thread.currentThread().getName());
for (int i = 0; i < 100; i++) {
	System.out.println("main thread");
}
}

}