package com.vidvaan.thread.daemonThread;

public class MyThread extends Thread {
	int count = 0;

	public void run() {
		while (true) {
			print();
			count++;

		}
	}

	void print() {
		try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		System.out.println("Daemon Executed" + count);
	}

}
