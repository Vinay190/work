package com.vidvaan.thread.daemonThread;

public class Test {
	public static void main(String[] args) {
		MyThread myThread = new MyThread();
		myThread.setDaemon(true);
		System.out.println(myThread.isDaemon());
		myThread.start();
		try {
			Thread.sleep(30000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		System.out.println("Thread finished");
	}
}