package com.vidvaan.thread.priorty;

public class Sample {

}
