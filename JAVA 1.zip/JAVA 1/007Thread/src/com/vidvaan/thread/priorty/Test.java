package com.vidvaan.thread.priorty;

public class Test {
	public static void main(String[] args) {
		Myclass myclass = new Myclass();
		myclass.setName("t1");
		myclass.setPriority(Thread.MAX_PRIORITY);
		Myclass myclass1 = new Myclass();
		myclass1.setName("t2");
		myclass1.setPriority(Thread.MIN_PRIORITY);
		myclass.start();
		myclass1.start();
		for (int i = 0; i < 10; i++) {
			System.out.println("mainThread");
		}
	}
}
