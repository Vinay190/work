function var(){
var x = 10;  
var y = 20;  
var z=x+y;  
document.write(z);  
}